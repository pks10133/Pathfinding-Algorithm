print("intro py maze")

from pyMaze import maze
